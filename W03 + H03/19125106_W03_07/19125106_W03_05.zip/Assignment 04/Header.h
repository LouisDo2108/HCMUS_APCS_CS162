#pragma once

#ifndef _Header_H_
#define _Header_H_

int findMode(int* arr, int& n);

#endif
