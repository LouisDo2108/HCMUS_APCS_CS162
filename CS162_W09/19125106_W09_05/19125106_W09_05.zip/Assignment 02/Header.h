#pragma once
#ifndef _Header_H_
#define	_Header_H_
#include <iostream>

using namespace std;

void inputDate();
void outputDate();
#endif // !_Header_H_
