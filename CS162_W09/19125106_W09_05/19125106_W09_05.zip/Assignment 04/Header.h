#pragma once
#ifndef _Header_H_
#define _Header_H_

#include <string>

using namespace std;

void split(string source, string destination, string mode, int x);
#endif // !_Header_H_
#pragma once
