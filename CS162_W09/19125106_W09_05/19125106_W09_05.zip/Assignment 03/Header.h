#pragma once
#ifndef _Header_H_
#define _Header_H_

#include <string>

using namespace std;

void copy(string source, string destination);
#endif // !_Header_H_
