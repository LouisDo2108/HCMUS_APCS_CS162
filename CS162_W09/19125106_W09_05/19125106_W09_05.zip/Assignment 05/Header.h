#pragma once
#ifndef _Header_H_
#define _Header_H_
#define _SILENCE_EXPERIMENTAL_FILESYSTEM_DEPRECATION_WARNING

#include <string>

using namespace std;

void merge(string source, string destination);
#endif // !_Header_H_
#pragma once
